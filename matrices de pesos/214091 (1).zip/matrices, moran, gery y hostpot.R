library(shiny)
library(sf)
library(spdep)
library(leaflet)
library(dplyr)
library(ggplot2)
library(shinythemes)
library(shinyjs)
library(bslib)
library(plotly)
library(DT)
library(shinyWidgets)
library(leaflet.extras)
library(bsicons)

# CSS personalizado estilo futurista
futurist_css <- "
/* Estilos futuristas */
:root {
  --primary: #00f5d4;
  --secondary: #7209b7;
  --dark: #0d0d0d;
  --darker: #1a1a1a;
  --light: #f8f9fa;
  --accent: #f15bb5;
}

body {
  background: linear-gradient(135deg, var(--dark) 0%, var(--darker) 100%);
  color: var(--light);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Header mejorado */
.navbar {
  background: rgba(13, 13, 13, 0.95) !important;
  backdrop-filter: blur(10px);
  border-bottom: 1px solid var(--primary);
}

/* Paneles con efecto glassmorphism */
.sidebar, .tab-content, .well {
  background: rgba(255, 255, 255, 0.05) !important;
  backdrop-filter: blur(15px);
  border: 1px solid rgba(0, 245, 212, 0.2);
  border-radius: 15px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
}

/* Botones futuristas */
.btn-primary {
  background: linear-gradient(45deg, var(--primary), var(--secondary));
  border: none;
  border-radius: 25px;
  font-weight: 600;
  transition: all 0.3s ease;
  box-shadow: 0 4px 15px rgba(0, 245, 212, 0.3);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0, 245, 212, 0.4);
}

/* Pestañas modernas */
.nav-tabs > li > a {
  color: var(--light) !important;
  border: none !important;
  border-radius: 10px 10px 0 0;
  margin-right: 5px;
  transition: all 0.3s ease;
}

.nav-tabs > li.active > a {
  background: linear-gradient(45deg, var(--primary), var(--secondary)) !important;
  color: var(--dark) !important;
  font-weight: bold;
}

/* Select inputs modernos */
.selectize-input {
  background: rgba(255, 255, 255, 0.1) !important;
  border: 1px solid var(--primary) !important;
  color: var(--light) !important;
  border-radius: 10px !important;
}

/* Slider personalizado */
.irs-bar, .irs-single, .irs-from, .irs-to {
  background: var(--primary) !important;
}

/* Cards de métricas */
.metric-card {
  background: rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  padding: 15px;
  margin: 10px 0;
  border-left: 4px solid var(--primary);
}

/* Animaciones */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

.fade-in {
  animation: fadeIn 0.6s ease-out;
}

/* Scrollbar personalizado */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: var(--darker);
}

::-webkit-scrollbar-thumb {
  background: var(--primary);
  border-radius: 4px;
}
"

# UI Mejorada
ui <- fluidPage(
  theme = bslib::bs_theme(
    version = 5,
    bg = "#0d0d0d",
    fg = "#f8f9fa",
    primary = "#00f5d4",
    secondary = "#7209b7",
    base_font = font_google("Inter"),
    heading_font = font_google("Inter")
  ),
  
  tags$head(
    tags$style(HTML(futurist_css)),
    tags$link(rel = "stylesheet", href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css")
  ),
  
  useShinyjs(),
  
  # Header futurista
  div(class = "navbar",
      fluidRow(
        column(8,
               h2("🚀 ANALIZADOR ESPACIAL - PRODUCCIÓN DE PAPA PUNO", 
                  style = "color: #00f5d4; margin: 15px 0; font-weight: 800;")
        ),
        column(4,
               div(style = "text-align: right; padding: 15px;",
                   tags$small("v2.0 • Análisis Inteligente • ", 
                              style = "color: #888;")
               )
        )
      )
  ),
  
  sidebarLayout(
    sidebarPanel(
      width = 3,
      class = "fade-in",
      
      # Panel de control mejorado
      div(class = "metric-card",
          h4("🎛️ PANEL DE CONTROL", style = "color: #00f5d4;"),
          hr(style = "border-color: #00f5d4;")
      ),
      
      pickerInput("year", 
                  label = tags$span(icon("calendar"), " AÑO DE ANÁLISIS"),
                  choices = c(2015:2019, 2021:2024),
                  selected = 2024,
                  options = list(style = "btn-primary")),
      
      pickerInput("variable", 
                  label = tags$span(icon("chart-line"), " VARIABLE PRINCIPAL"),
                  choices = c("Rendimiento (kg/ha)" = "rendimiento",
                              "Producción (kg)" = "P219_EQUIV_KG",
                              "Superficie (ha)" = "P217_SUP_ha",
                              "Precio Unitario" = "precio_unitario"),
                  selected = "rendimiento"),
      
      pickerInput("nivel_geografico", 
                  label = tags$span(icon("globe-americas"), " NIVEL GEOGRÁFICO"),
                  choices = c("Provincia" = "NOMBREPV",
                              "Distrito" = "NOMBREDI"),
                  selected = "NOMBREPV"),
      
      pickerInput("tipo_papa", 
                  label = tags$span(icon("seedling"), " TIPO DE PAPA"),
                  choices = c("Todos los tipos" = "todos",
                              "PAPA NATIVA" = "PAPA NATIVA",
                              "PAPA AMARGA" = "PAPA AMARGA",
                              "PAPA BLANCA" = "PAPA BLANCA",
                              "PAPA COLOR" = "PAPA COLOR",
                              "PAPA HUAYRO" = "PAPA HUAYRO"),
                  selected = "todos",
                  multiple = FALSE),
      
      # Slider mejorado
      div(class = "metric-card",
          sliderTextInput("neighbors",
                          label = tags$span(icon("project-diagram"), " VECINOS ESPACIALES (k)"),
                          choices = 1:8,
                          selected = 4,
                          grid = TRUE)
      ),
      
      # Botones de acción
      fluidRow(
        column(6,
               actionBttn("analizar", 
                          "EJECUTAR ANÁLISIS", 
                          style = "gradient",
                          color = "primary",
                          size = "md",
                          block = TRUE)
        ),
        column(6,
               actionBttn("reset", 
                          "REINICIAR", 
                          style = "material-flat",
                          color = "warning",
                          size = "md",
                          block = TRUE)
        )
      ),
      
      br(),
      
      # Métricas rápidas
      uiOutput("metricas_rapidas")
      
    ),
    
    mainPanel(
      width = 9,
      tabsetPanel(
        id = "main_tabs",
        type = "pills",
        
        # Tab 1: Dashboard
        tabPanel(
          title = tags$span(icon("dashboard"), " DASHBOARD"),
          icon = icon("gauge"),
          fluidRow(
            column(4, uiOutput("card_moran")),
            column(4, uiOutput("card_geary")),
            column(4, uiOutput("card_hotspots"))
          ),
          fluidRow(
            column(8, leafletOutput("mapa_principal", height = "500px")),
            column(4, 
                   plotlyOutput("grafico_tendencia", height = "250px"),
                   plotlyOutput("grafico_distribucion", height = "230px")
            )
          )
        ),
        
        # Tab 2: Análisis Espacial Avanzado
        tabPanel(
          title = tags$span(icon("globe"), " ANÁLISIS ESPACIAL"),
          fluidRow(
            column(6, 
                   div(class = "metric-card",
                       h4("🌍 MATRIZ DE PESOS ESPACIALES"),
                       verbatimTextOutput("resumen_pesos"),
                       plotlyOutput("grafico_conectividad", height = "200px")
                   )
            ),
            column(6,
                   div(class = "metric-card",
                       h4("📊 AUTOCORRELACIÓN ESPACIAL"),
                       tabsetPanel(
                         tabPanel("Moran", verbatimTextOutput("resultado_moran")),
                         tabPanel("Geary", verbatimTextOutput("resultado_geary"))
                       )
                   )
            )
          )
        ),
        
        # Tab 3: Hotspots
        tabPanel(
          title = tags$span(icon("fire"), " HOTSPOTS & CLUSTERS"),
          fluidRow(
            column(8, leafletOutput("mapa_hotspots", height = "550px")),
            column(4,
                   plotlyOutput("grafico_hotspots", height = "250px"),
                   dataTableOutput("tabla_hotspots")
            )
          )
        ),
        
        # Tab 4: Data Explorer
        tabPanel(
          title = tags$span(icon("database"), " EXPLORADOR DE DATOS"),
          fluidRow(
            column(4,
                   div(class = "metric-card",
                       h4("📈 ESTADÍSTICAS DESCRIPTIVAS"),
                       verbatimTextOutput("resumen_estadistico")
                   )
            ),
            column(8,
                   dataTableOutput("tabla_datos")
            )
          )
        )
      )
    )
  )
)

# SERVER MEJORADO
server <- function(input, output, session) {
  
  # Coordenadas corregidas para Puno (más precisas)
  coordenadas_corregidas <- reactive({
    data.frame(
      ubicacion = c(
        "PUNO", "AZÁNGARO", "SAN ROMÁN", "JULI", "ILAVE", 
        "YUNGUYO", "HUANCANÉ", "LAMPA", "MELGAR", "SANDIA", 
        "CARABAYA", "EL COLLAO", "CHUCUITO", "MOHO",
        # Distritos importantes
        "OLLACHEA", "MACUSANI", "CORANI", "USICAYOS", "COJATA", "HUACULLANI",
        "JULIACA", "AYAVIRI", "PICHACANI", "ACORA", "ATUNCOLLA", "CAPACHICA",
        "COATA", "HUATA", "PAUCARCOLLA", "TARACO", "VILQUECHICO", "MAÑAZO",
        "POMATA", "ZEPITA", "DESAGUADERO", "SAN ANTONIO", "SAN JUAN", "CONIMA"
      ),
      lat = c(
        # Provincias
        -15.8402, -14.9086, -15.4917, -16.2167, -16.0833,
        -16.2500, -15.2000, -15.3667, -14.8167, -14.2333,
        -13.8333, -16.0000, -16.6000, -15.3167,
        # Distritos
        -13.7500, -14.0667, -13.8167, -14.0500, -16.6000, -16.5000,
        -15.4917, -14.8833, -16.2333, -15.9667, -15.6833, -15.6333,
        -15.5667, -15.6167, -15.6667, -16.2333, -15.7667, -16.4167,
        -16.2667, -16.5000, -16.5667, -16.4833, -15.3500, -15.3167
      ),
      lon = c(
        # Provincias
        -70.0219, -70.1969, -70.1333, -69.4583, -69.6667,
        -69.0833, -69.7583, -70.3667, -70.8167, -69.4667,
        -70.3583, -69.7167, -69.2833, -69.4333,
        # Distritos
        -70.4167, -70.4333, -70.3583, -70.2167, -69.1833, -69.3500,
        -70.1333, -70.5833, -69.7167, -69.7667, -70.1500, -69.8333,
        -70.0667, -70.1000, -70.0500, -69.9667, -70.2333, -70.6667,
        -69.2833, -69.1000, -69.0333, -70.3333, -69.9000, -69.4667
      )
    )
  })
  
  # Cargar datos reales
  datos_reales <- reactive({
    datos <- read.csv("datos_final.csv", stringsAsFactors = FALSE)
    
    # Limpieza mejorada
    datos <- datos %>%
      mutate(
        P219_EQUIV_KG = as.numeric(P219_EQUIV_KG),
        P217_SUP_ha = as.numeric(P217_SUP_ha),
        precio_unitario = as.numeric(precio_unitario),
        rendimiento = as.numeric(rendimiento),
        ANIO = as.integer(ANIO),
        tipo_papa = ifelse(is.na(P204_NOM), "NO ESPECIFICADO", P204_NOM),
        # Limpieza adicional para coordenadas
        NOMBREPV = trimws(toupper(NOMBREPV)),
        NOMBREDI = trimws(toupper(NOMBREDI))
      )
    
    return(datos)
  })
  
  # Filtrar datos
  datos_filtrados <- eventReactive(input$analizar, {
    datos <- datos_reales()
    
    # Aplicar filtros
    datos_filtrados <- datos[datos$ANIO == input$year, ]
    
    if(input$tipo_papa != "todos") {
      datos_filtrados <- datos_filtrados[datos_filtrados$tipo_papa == input$tipo_papa, ]
    }
    
    # Agregar datos
    columna_geo <- input$nivel_geografico
    var_analisis <- input$variable
    
    datos_agg <- datos_filtrados %>%
      rename(ubicacion = !!columna_geo) %>%
      group_by(ubicacion) %>%
      summarise(
        valor = mean(get(var_analisis), na.rm = TRUE),
        n_observaciones = n(),
        .groups = 'drop'
      ) %>%
      filter(!is.na(valor), !is.na(ubicacion), ubicacion != "", n_observaciones > 0)
    
    names(datos_agg)[names(datos_agg) == "valor"] <- var_analisis
    
    return(datos_agg)
  })
  
  # Crear objeto espacial con coordenadas corregidas
  datos_espaciales <- reactive({
    datos <- datos_filtrados()
    if(nrow(datos) == 0) return(NULL)
    
    # Usar coordenadas corregidas
    coords_base <- coordenadas_corregidas()
    
    # Unir con coordenadas base
    datos_coords <- merge(datos, coords_base, by = "ubicacion", all.x = TRUE)
    
    # Para ubicaciones sin coordenadas, usar algoritmo de aproximación mejorado
    if(any(is.na(datos_coords$lat))) {
      sin_coords <- is.na(datos_coords$lat)
      
      # Asignar coordenadas basadas en ubicaciones conocidas cercanas
      for(i in which(sin_coords)) {
        ubicacion_actual <- datos_coords$ubicacion[i]
        
        # Buscar ubicación similar en nombres
        ubicaciones_similares <- agrep(ubicacion_actual, coords_base$ubicacion, 
                                       max.distance = 0.3, value = TRUE)
        
        if(length(ubicaciones_similares) > 0) {
          coords_similar <- coords_base[coords_base$ubicacion == ubicaciones_similares[1], ]
          datos_coords$lat[i] <- coords_similar$lat
          datos_coords$lon[i] <- coords_similar$lon
        } else {
          # Coordenadas aleatorias dentro de Puno con distribución más realista
          datos_coords$lat[i] <- runif(1, -16.8, -13.5)
          datos_coords$lon[i] <- runif(1, -71.0, -68.5)
        }
      }
    }
    
    # Convertir a objeto espacial
    datos_sf <- st_as_sf(datos_coords, coords = c("lon", "lat"), crs = 4326)
    
    return(datos_sf)
  })
  
  # Matriz de pesos
  matriz_pesos <- reactive({
    datos_sf <- datos_espaciales()
    if(is.null(datos_sf) || nrow(datos_sf) < 3) return(NULL)
    
    coords <- st_coordinates(datos_sf)
    k <- min(as.numeric(input$neighbors), nrow(datos_sf) - 1)
    
    nb <- knn2nb(knearneigh(coords, k = k))
    listw <- nb2listw(nb, style = "W", zero.policy = TRUE)
    
    return(list(listw = listw, coords = coords, nb = nb))
  })
  
  # Métricas rápidas en sidebar
  output$metricas_rapidas <- renderUI({
    datos <- datos_filtrados()
    if(nrow(datos) == 0) return(NULL)
    
    var_analisis <- input$variable
    
    div(
      class = "metric-card",
      h5("📊 MÉTRICAS RÁPIDAS", style = "color: #00f5d4;"),
      tags$small(paste("Ubicaciones:", nrow(datos))),
      tags$br(),
      tags$small(paste("Media:", round(mean(datos[[var_analisis]], na.rm = TRUE), 1))),
      tags$br(),
      tags$small(paste("Máximo:", round(max(datos[[var_analisis]], na.rm = TRUE), 1)))
    )
  })
  
  # Cards del dashboard
  output$card_moran <- renderUI({
    datos_sf <- datos_espaciales()
    pesos <- matriz_pesos()
    
    if(is.null(pesos)) {
      moran_text <- "N/D"
      color <- "warning"
    } else {
      x <- datos_sf[[input$variable]]
      if(length(x) > 2 && var(x, na.rm = TRUE) > 0) {
        moran_test <- moran.test(x, pesos$listw, zero.policy = TRUE)
        moran_text <- round(moran_test$estimate[1], 3)
        color <- ifelse(moran_test$p.value < 0.05, "success", "warning")
      } else {
        moran_text <- "N/D"
        color <- "warning"
      }
    }
    
    div(class = "metric-card",
        h4("🌐 MORAN'S I"),
        h3(style = paste0("color: ", ifelse(color == "success", "#00f5d4", "#ff6b6b")), moran_text),
        tags$small("Autocorrelación Espacial Global")
    )
  })
  
  output$card_geary <- renderUI({
    datos_sf <- datos_espaciales()
    pesos <- matriz_pesos()
    
    if(is.null(pesos)) {
      geary_text <- "N/D"
    } else {
      x <- datos_sf[[input$variable]]
      if(length(x) > 2 && var(x, na.rm = TRUE) > 0) {
        geary_test <- geary.test(x, pesos$listw, zero.policy = TRUE)
        geary_text <- round(geary_test$estimate[1], 3)
      } else {
        geary_text <- "N/D"
      }
    }
    
    div(class = "metric-card",
        h4("🔍 GEARY'S C"),
        h3(style = "color: #f15bb5;", geary_text),
        tags$small("Autocorrelación Local")
    )
  })
  
  output$card_hotspots <- renderUI({
    datos_sf <- datos_espaciales()
    if(is.null(datos_sf) || !"quadrant" %in% names(datos_sf)) {
      hotspot_count <- 0
    } else {
      hotspot_count <- sum(datos_sf$quadrant == "Hotspot", na.rm = TRUE)
    }
    
    div(class = "metric-card",
        h4("🔥 HOTSPOTS"),
        h3(style = "color: #ff6b6b;", hotspot_count),
        tags$small("Clusters Significativos")
    )
  })
  
  # Mapa principal mejorado
  output$mapa_principal <- renderLeaflet({
    datos_sf <- datos_espaciales()
    if(is.null(datos_sf)) return(NULL)
    
    var_seleccionada <- input$variable
    valores <- datos_sf[[var_seleccionada]]
    
    # Paleta mejorada
    pal <- colorNumeric(
      palette = c("#1a1a2e", "#16213e", "#0f3460", "#00f5d4", "#f15bb5"),
      domain = valores
    )
    
    # Etiquetas mejoradas
    labels <- sprintf(
      "<div style='background: rgba(13,13,13,0.9); padding: 10px; border-radius: 8px; border: 1px solid #00f5d4;'>
       <strong style='color: #00f5d4;'>%s</strong><br/>
       <span style='color: #f8f9fa;'>%s: <strong>%.2f</strong></span><br/>
       <span style='color: #888;'>Observaciones: %d</span>
       </div>",
      datos_sf$ubicacion,
      var_seleccionada,
      valores,
      datos_sf$n_observaciones
    ) %>% lapply(htmltools::HTML)
    
    leaflet(datos_sf) %>%
      addProviderTiles(providers$CartoDB.DarkMatter,
                       options = providerTileOptions(opacity = 0.8)) %>%
      addCircleMarkers(
        radius = ~sqrt(n_observaciones) * 3 + 5,
        color = ~pal(valores),
        stroke = TRUE,
        weight = 2,
        opacity = 0.8,
        fillOpacity = 0.7,
        label = labels,
        popup = labels,
        clusterOptions = markerClusterOptions(
          spiderfyOnMaxZoom = TRUE,
          showCoverageOnHover = TRUE,
          zoomToBoundsOnClick = TRUE
        )
      ) %>%
      addLegend(
        position = "bottomright",
        pal = pal,
        values = ~valores,
        title = var_seleccionada,
        opacity = 0.8,
        labFormat = labelFormat(
          transform = function(x) round(x, 2)
        )
      ) %>%
      addScaleBar(position = "bottomleft") %>%
      addFullscreenControl()
  })
  
  # Gráficos Plotly mejorados
  output$grafico_tendencia <- renderPlotly({
    datos <- datos_reales()
    var_analisis <- input$variable
    
    tendencia <- datos %>%
      group_by(ANIO) %>%
      summarise(
        media = mean(get(var_analisis), na.rm = TRUE),
        .groups = 'drop'
      )
    
    plot_ly(tendencia, x = ~ANIO, y = ~media, type = 'scatter', mode = 'lines+markers',
            line = list(color = '#00f5d4', width = 4),
            marker = list(color = '#f15bb5', size = 8),
            hovertemplate = paste('Año: %{x}<br>', var_analisis, ': %{y:.2f}<extra></extra>')) %>%
      layout(
        title = list(text = "📈 TENDENCIA TEMPORAL", font = list(color = '#f8f9fa')),
        paper_bgcolor = 'rgba(0,0,0,0)',
        plot_bgcolor = 'rgba(0,0,0,0)',
        font = list(color = '#f8f9fa'),
        xaxis = list(title = "Año", gridcolor = '#333'),
        yaxis = list(title = var_analisis, gridcolor = '#333')
      )
  })
  
  output$grafico_distribucion <- renderPlotly({
    datos <- datos_filtrados()
    if(nrow(datos) == 0) return(NULL)
    
    var_analisis <- input$variable
    
    plot_ly(datos, x = ~get(var_analisis), type = "histogram",
            marker = list(color = '#7209b7',
                          line = list(color = '#00f5d4', width = 1))) %>%
      layout(
        title = list(text = "📊 DISTRIBUCIÓN", font = list(color = '#f8f9fa')),
        paper_bgcolor = 'rgba(0,0,0,0)',
        plot_bgcolor = 'rgba(0,0,0,0)',
        font = list(color = '#f8f9fa'),
        xaxis = list(title = var_analisis, gridcolor = '#333'),
        yaxis = list(title = "Frecuencia", gridcolor = '#333')
      )
  })
  
  # Resto de outputs (manteniendo la funcionalidad original pero con mejoras estéticas)
  output$resumen_pesos <- renderPrint({
    pesos <- matriz_pesos()
    if(is.null(pesos)) {
      cat("⏳ Esperando datos suficientes...\n")
      return()
    }
    
    cat("🌐 MATRIZ DE PESOS ESPACIALES\n")
    cat("================================\n")
    cat("🔗 Tipo: Vecinos k-nn\n")
    cat("👥 Vecinos (k):", input$neighbors, "\n")
    cat("📍 Ubicaciones:", length(pesos$listw$neighbours), "\n")
    cat("📊 Conectividad:", round(mean(card(pesos$nb)), 2), "\n")
    cat("🎯 Estandarización: W (fila-estandarizada)\n")
  })
  
  output$grafico_conectividad <- renderPlotly({
    pesos <- matriz_pesos()
    if(is.null(pesos)) return(NULL)
    
    card_dist <- as.data.frame(table(card(pesos$nb)))
    
    plot_ly(card_dist, x = ~Var1, y = ~Freq, type = 'bar',
            marker = list(color = '#00f5d4',
                          line = list(color = '#f15bb5', width = 2))) %>%
      layout(
        title = list(text = "🔗 DISTRIBUCIÓN DE CONECTIVIDAD", font = list(color = '#f8f9fa')),
        paper_bgcolor = 'rgba(0,0,0,0)',
        plot_bgcolor = 'rgba(0,0,0,0)',
        font = list(color = '#f8f9fa'),
        xaxis = list(title = "Número de Vecinos", gridcolor = '#333'),
        yaxis = list(title = "Frecuencia", gridcolor = '#333')
      )
  })
  
  output$resultado_moran <- renderPrint({
    datos_sf <- datos_espaciales()
    pesos <- matriz_pesos()
    
    if(is.null(pesos)) {
      cat("⏳ Calculando...\n")
      return()
    }
    
    x <- datos_sf[[input$variable]]
    
    if(length(x) > 2 && var(x, na.rm = TRUE) > 0) {
      moran_test <- moran.test(x, pesos$listw, zero.policy = TRUE)
      cat("🌐 PRUEBA DE MORAN'S I\n")
      cat("=====================\n")
      print(moran_test)
    } else {
      cat("❌ Datos insuficientes para cálculo\n")
    }
  })
  
  output$resultado_geary <- renderPrint({
    datos_sf <- datos_espaciales()
    pesos <- matriz_pesos()
    
    if(is.null(pesos)) {
      cat("⏳ Calculando...\n")
      return()
    }
    
    x <- datos_sf[[input$variable]]
    
    if(length(x) > 2 && var(x, na.rm = TRUE) > 0) {
      geary_test <- geary.test(x, pesos$listw, zero.policy = TRUE)
      cat("🔍 PRUEBA DE GEARY'S C\n")
      cat("=====================\n")
      print(geary_test)
    } else {
      cat("❌ Datos insuficientes para cálculo\n")
    }
  })
  
  output$mapa_hotspots <- renderLeaflet({
    datos_sf <- datos_espaciales()
    pesos <- matriz_pesos()
    
    if(is.null(pesos)) return(NULL)
    
    x <- datos_sf[[input$variable]]
    
    if(length(x) > 2 && var(x, na.rm = TRUE) > 0) {
      local_moran <- localmoran(x, pesos$listw, zero.policy = TRUE)
      
      # Clasificación mejorada
      datos_sf$quadrant <- "No significativo"
      datos_sf$quadrant[local_moran[,5] < 0.10 & x > mean(x) & local_moran[,1] > 0] <- "🔥 Hotspot"
      datos_sf$quadrant[local_moran[,5] < 0.10 & x < mean(x) & local_moran[,1] > 0] <- "❄️ Coldspot"
      datos_sf$quadrant[local_moran[,5] < 0.10 & x > mean(x) & local_moran[,1] < 0] <- "⚡ Outlier Alto"
      datos_sf$quadrant[local_moran[,5] < 0.10 & x < mean(x) & local_moran[,1] < 0] <- "💤 Outlier Bajo"
      
      # Paleta mejorada para hotspots
      pal_hotspots <- colorFactor(
        palette = c("#ff6b6b", "#4ecdc4", "#ffd166", "#06d6a0", "#888888"),
        domain = datos_sf$quadrant
      )
      
      # Etiquetas mejoradas
      labels <- sprintf(
        "<div style='background: rgba(13,13,13,0.95); padding: 12px; border-radius: 10px; border: 2px solid %s;'>
         <strong style='color: %s; font-size: 14px;'>%s</strong><br/>
         <span style='color: #f8f9fa;'>📊 %s: <strong>%.2f</strong></span><br/>
         <span style='color: %s;'>🏷️ %s</span><br/>
         <span style='color: #888;'>👁️ Observaciones: %d</span>
         </div>",
        pal_hotspots(datos_sf$quadrant),
        pal_hotspots(datos_sf$quadrant),
        datos_sf$ubicacion,
        input$variable,
        x,
        pal_hotspots(datos_sf$quadrant),
        datos_sf$quadrant,
        datos_sf$n_observaciones
      ) %>% lapply(htmltools::HTML)
      
      leaflet(datos_sf) %>%
        addProviderTiles(providers$CartoDB.DarkMatter) %>%
        addCircleMarkers(
          radius = 10,
          color = ~pal_hotspots(quadrant),
          stroke = TRUE,
          weight = 3,
          opacity = 1,
          fillOpacity = 0.8,
          label = labels,
          popup = labels
        ) %>%
        addLegend(
          position = "bottomright",
          pal = pal_hotspots,
          values = ~quadrant,
          title = "🎯 CLASIFICACIÓN LISA",
          opacity = 0.9
        ) %>%
        addScaleBar() %>%
        addFullscreenControl()
    }
  })
  
  output$grafico_hotspots <- renderPlotly({
    datos_sf <- datos_espaciales()
    if(is.null(datos_sf) || !"quadrant" %in% names(datos_sf)) return(NULL)
    
    hotspot_counts <- as.data.frame(table(datos_sf$quadrant))
    
    plot_ly(hotspot_counts, labels = ~Var1, values = ~Freq, type = 'pie',
            marker = list(colors = c('#ff6b6b', '#4ecdc4', '#ffd166', '#06d6a0', '#888888'),
                          line = list(color = '#0d0d0d', width = 2))) %>%
      layout(
        title = list(text = "📈 DISTRIBUCIÓN DE CLUSTERS", font = list(color = '#f8f9fa')),
        paper_bgcolor = 'rgba(0,0,0,0)',
        plot_bgcolor = 'rgba(0,0,0,0)',
        font = list(color = '#f8f9fa'),
        showlegend = TRUE
      )
  })
  
  output$tabla_hotspots <- renderDataTable({
    datos_sf <- datos_espaciales()
    if(is.null(datos_sf) || !"quadrant" %in% names(datos_sf)) return(NULL)
    
    tabla <- st_drop_geometry(datos_sf) %>%
      select(ubicacion, quadrant, !!input$variable, n_observaciones) %>%
      arrange(desc(get(input$variable)))
    
    datatable(tabla,
              options = list(
                pageLength = 5,
                dom = 'tip',
                scrollX = TRUE
              ),
              class = 'cell-border stripe hover',
              rownames = FALSE) %>%
      formatRound(columns = input$variable, digits = 2)
  })
  
  output$resumen_estadistico <- renderPrint({
    datos <- datos_filtrados()
    if(nrow(datos) == 0) {
      cat("📊 ESPERANDO DATOS...\n")
      return()
    }
    
    var_analisis <- input$variable
    
    cat("📈 ESTADÍSTICAS DESCRIPTIVAS\n")
    cat("============================\n")
    cat("📅 Año:", input$year, "\n")
    cat("🥔 Tipo:", input$tipo_papa, "\n")
    cat("🗺️ Nivel:", input$nivel_geografico, "\n")
    cat("📍 Ubicaciones:", nrow(datos), "\n")
    cat("👁️ Observaciones:", sum(datos$n_observaciones), "\n\n")
    cat("📊", var_analisis, "\n")
    cat("--------------------\n")
    cat("📐 Media:", round(mean(datos[[var_analisis]], na.rm = TRUE), 2), "\n")
    cat("📏 Desv. Estándar:", round(sd(datos[[var_analisis]], na.rm = TRUE), 2), "\n")
    cat("📉 Mínimo:", round(min(datos[[var_analisis]], na.rm = TRUE), 2), "\n")
    cat("📈 Máximo:", round(max(datos[[var_analisis]], na.rm = TRUE), 2), "\n")
    cat("❌ Faltantes:", sum(is.na(datos[[var_analisis]])), "\n")
  })
  
  output$tabla_datos <- renderDataTable({
    datos <- datos_filtrados()
    if(nrow(datos) == 0) return(NULL)
    
    datatable(datos,
              options = list(
                pageLength = 10,
                dom = 'Blfrtip',
                buttons = c('copy', 'csv', 'excel'),
                scrollX = TRUE
              ),
              extensions = 'Buttons',
              class = 'cell-border stripe hover',
              rownames = FALSE) %>%
      formatRound(columns = input$variable, digits = 2)
  })
  
  # Observador para el botón reset
  observeEvent(input$reset, {
    updatePickerInput(session, "year", selected = 2024)
    updatePickerInput(session, "variable", selected = "rendimiento")
    updatePickerInput(session, "nivel_geografico", selected = "NOMBREPV")
    updatePickerInput(session, "tipo_papa", selected = "todos")
    updateSliderTextInput(session, "neighbors", selected = 4)
  })
}

shinyApp(ui = ui, server = server)

