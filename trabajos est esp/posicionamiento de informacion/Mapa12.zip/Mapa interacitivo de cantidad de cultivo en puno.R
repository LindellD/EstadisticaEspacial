library(shiny)
library(leaflet)
library(dplyr)
library(sf)
library(readr)
library(RColorBrewer)

# === 1. Cargar la base filtrada ===
base_filtrada <- read_csv("base_filtrada.csv")

# === 2. Cargar geometría de Perú desde GeoJSON ===
peru <- st_read("https://raw.githubusercontent.com/johan/world.geo.json/master/countries/PER.geo.json")

# Coordenadas aproximadas de Puno
coords_puno <- data.frame(
  lon = -69.98,
  lat = -15.84
)

# === 3. App Shiny ===
ui <- fluidPage(
  titlePanel("Mapa interactivo de cultivos en Puno"),
  sidebarLayout(
    sidebarPanel(
      selectInput("anio", "Selecciona el año:", choices = unique(base_filtrada$ANIO)),
      selectInput("cultivo", "Selecciona el cultivo:", choices = unique(base_filtrada$P204_NOM))
    ),
    mainPanel(
      leafletOutput("mapa", height = 600),
      br(),
      h4("Estadísticas descriptivas"),
      tableOutput("tabla_stats")
    )
  )
)

server <- function(input, output, session) {
  
  # Reactive: filtrar datos
  datos_filtrados <- reactive({
    base_filtrada %>%
      filter(ANIO == input$anio, P204_NOM == input$cultivo) %>%
      summarise(total = n(), .groups = "drop")
  })
  
  # Render del mapa
  output$mapa <- renderLeaflet({
    datos <- datos_filtrados()
    total_val <- ifelse(nrow(datos) > 0, datos$total, 0)
    
    # Escala de colores para cantidades
    max_val <- max(table(base_filtrada$P204_NOM), na.rm = TRUE)
    pal <- colorNumeric(palette = c("yellow", "red"), domain = c(0, max_val))
    
    leaflet(peru) %>%
      addTiles() %>%
      addPolygons(
        fillColor = "lightgray",
        weight = 1,
        opacity = 1,
        color = "black",
        fillOpacity = 0.5
      ) %>%
      addCircleMarkers(
        lng = coords_puno$lon,
        lat = coords_puno$lat,
        radius = 20,
        color = pal(total_val),
        stroke = TRUE,
        fillOpacity = 0.8,
        label = paste0("Puno\n", input$cultivo, ": ", total_val, " registros")
      ) %>%
      addLegend(
        pal = pal,
        values = c(0, max_val),
        opacity = 0.8,
        title = "Cantidad de producción",
        labFormat = labelFormat(suffix = " registros")
      )
  })
  
  # Estadísticas descriptivas
  output$tabla_stats <- renderTable({
    datos_filtrados() %>%
      rename(`Total producción` = total)
  })
}

shinyApp(ui, server)


