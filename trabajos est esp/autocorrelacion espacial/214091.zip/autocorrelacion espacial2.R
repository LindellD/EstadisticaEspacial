# =====================================
# AUTOCORRELACIÓN ESPACIAL - EJEMPLO SIMPLE
# =====================================

# Paquetes requeridos
library(sf)
library(spdep)
library(leaflet)
library(RColorBrewer)
library(dplyr)

# -------------------------------------
# 1) Simular datos espaciales
# -------------------------------------
set.seed(123)
n <- 100
x <- runif(n, -10, 10)
y <- runif(n, -10, 10)

# Creamos un sf con puntos
puntos <- st_as_sf(data.frame(id = 1:n, x = x, y = y), coords = c("x", "y"), crs = 4326)

# Simular variable con autocorrelación espacial
# (zona este con valores más altos)
coords <- st_coordinates(puntos)
valor <- 0.5 + 0.4 * (coords[,1] / max(coords[,1])) + rnorm(n, sd = 0.1)
puntos$valor <- pmin(pmax(valor, 0), 1) # restringido entre 0 y 1

# -------------------------------------
# 2) Calcular Moran Global y Local (LISA)
# -------------------------------------
# Crear vecinos k=6
nb <- knn2nb(knearneigh(coords, k = 6))
lw <- nb2listw(nb, style = "W")

# Moran Global
moran_global <- moran.test(puntos$valor, lw)
print(moran_global)

# LISA (Local Moran)
lisa <- localmoran(puntos$valor, lw)
puntos$I_local <- lisa[,1]
puntos$pvalor <- lisa[,5]

# Clasificación de clusters
mean_val <- mean(puntos$valor)
lag_val <- lag.listw(lw, puntos$valor)
cluster <- rep("No significativo", n)
cluster[puntos$valor > mean_val & lag_val > mean_val & puntos$pvalor < 0.05] <- "Alta-Alta"
cluster[puntos$valor < mean_val & lag_val < mean_val & puntos$pvalor < 0.05] <- "Baja-Baja"
cluster[puntos$valor > mean_val & lag_val < mean_val & puntos$pvalor < 0.05] <- "Alta-Baja"
cluster[puntos$valor < mean_val & lag_val > mean_val & puntos$pvalor < 0.05] <- "Baja-Alta"
puntos$cluster <- cluster

# -------------------------------------
# 3) Visualización interactiva con leaflet
# -------------------------------------

# Paletas de color
pal_valor <- colorNumeric(palette = "YlGnBu", domain = puntos$valor)
pal_cluster <- colorFactor(palette = c("red","blue","orange","purple","gray"),
                           domain = c("Alta-Alta","Baja-Baja","Alta-Baja","Baja-Alta","No significativo"))

# Mapa de variable
mapa_valor <- leaflet(puntos) %>%
  addProviderTiles("CartoDB.Positron") %>%
  addCircleMarkers(radius = 6, stroke = FALSE, fillOpacity = 0.9,
                   color = ~pal_valor(valor),
                   popup = ~paste0("<b>ID:</b> ", id, "<br><b>Valor:</b> ", round(valor,3),
                                   "<br><b>I Local:</b> ", round(I_local,3),
                                   "<br><b>p-valor:</b> ", round(pvalor,3))) %>%
  addLegend("bottomright", pal = pal_valor, values = ~valor, title = "Valor simulado")

# Mapa de clusters LISA
mapa_clusters <- leaflet(puntos) %>%
  addProviderTiles("CartoDB.Positron") %>%
  addCircleMarkers(radius = 6, stroke = TRUE, weight = 1,
                   color = ~pal_cluster(cluster), fillOpacity = 0.9,
                   popup = ~paste0("<b>ID:</b> ", id,
                                   "<br><b>Cluster:</b> ", cluster,
                                   "<br><b>Valor:</b> ", round(valor,3))) %>%
  addLegend("bottomright", pal = pal_cluster, values = ~cluster, title = "Cluster LISA")

# Mostrar mapas
mapa_valor
mapa_clusters
